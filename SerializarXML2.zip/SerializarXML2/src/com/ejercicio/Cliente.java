package com.ejercicio;

public class Cliente {
	private String nombre;
	private String cuidad;
	private int facturacion;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCuidad() {
		return cuidad;
	}
	public void setCuidad(String cuidad) {
		this.cuidad = cuidad;
	}
	public int getFacturacion() {
		return facturacion;
	}
	public void setFacturacion(int facturacion) {
		this.facturacion = facturacion;
	}
	
	

}
