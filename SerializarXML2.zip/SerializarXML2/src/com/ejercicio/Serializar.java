package com.ejercicio;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class Serializar {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		XmlMapper mapear=new XmlMapper();
		Cliente cliente=new Cliente();
		
		cliente.setNombre("Maria");
		cliente.setCuidad("Madrid");
		cliente.setFacturacion(2200);
		
		String guardarCliente=mapear.writeValueAsString(cliente);
		System.out.println(guardarCliente);
		File xmlOutput = new File("serialized.xml");
		FileWriter fileWriter = new FileWriter(xmlOutput);
		fileWriter.write(guardarCliente);
		fileWriter.close();
	

	}

}
